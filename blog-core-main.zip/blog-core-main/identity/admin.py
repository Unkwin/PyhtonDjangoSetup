from django.contrib import admin
from .models import Identity


admin.site.register(Identity)

